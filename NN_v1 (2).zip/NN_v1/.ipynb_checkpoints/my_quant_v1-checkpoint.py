import nni
from nni.compression.quantization import QATQuantizer
from nni.compression.quantization import PtqQuantizer
from nni.compression import TorchEvaluator
from torch.optim import SGD
from torch.optim import Adam
import torch.nn as nn
import time
import torch
import pandas as pd
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
import json


class ComplexMLP(nn.Module):
    def __init__(self, input_size, hidden_size1, hidden_size2, hidden_size3, hidden_size4, hidden_size5, hidden_size6, hidden_size7, hidden_size8, output_size):
        super(ComplexMLP, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size1)
        self.bn1 = nn.BatchNorm1d(hidden_size1)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Linear(hidden_size1, hidden_size2)
        self.bn2 = nn.BatchNorm1d(hidden_size2)
        self.relu2 = nn.ReLU()
        self.fc3 = nn.Linear(hidden_size2, hidden_size3)
        self.bn3 = nn.BatchNorm1d(hidden_size3)
        self.relu3 = nn.ReLU()
        self.fc4 = nn.Linear(hidden_size3, hidden_size4)
        self.bn4 = nn.BatchNorm1d(hidden_size4)
        self.relu4 = nn.ReLU()
        self.fc5 = nn.Linear(hidden_size4, hidden_size5)
        self.bn5 = nn.BatchNorm1d(hidden_size5)
        self.relu5 = nn.ReLU()
        self.fc6 = nn.Linear(hidden_size5, hidden_size6)
        self.bn6 = nn.BatchNorm1d(hidden_size6)
        self.relu6 = nn.ReLU()
        self.fc7 = nn.Linear(hidden_size6, hidden_size7)
        self.bn7 = nn.BatchNorm1d(hidden_size7)
        self.relu7 = nn.ReLU()
        self.fc8 = nn.Linear(hidden_size7, hidden_size8)
        self.bn8 = nn.BatchNorm1d(hidden_size8)
        self.relu8 = nn.ReLU()
        self.fc9 = nn.Linear(hidden_size8, output_size)

    def forward(self, x):
        x = self.fc1(x)
        x = self.bn1(x)
        x = self.relu1(x)
        x = self.fc2(x)
        x = self.bn2(x)
        x = self.relu2(x)
        x = self.fc3(x)
        x = self.bn3(x)
        x = self.relu3(x)
        x = self.fc4(x)
        x = self.bn4(x)
        x = self.relu4(x)
        x = self.fc5(x)
        x = self.bn5(x)
        x = self.relu5(x)
        x = self.fc6(x)
        x = self.bn6(x)
        x = self.relu6(x)
        x = self.fc7(x)
        x = self.bn7(x)
        x = self.relu7(x)
        x = self.fc8(x)
        x = self.bn8(x)
        x = self.relu8(x)
        x = self.fc9(x)
        return x


device = 'cpu'
# 训练数据
df = pd.read_csv('./4dataset1000.csv')
train_data_columns = df.columns[:27]
train_label_columns = df.columns[27:]  # 只选择第一个output的列
train_data = torch.tensor(df[train_data_columns].values, dtype=torch.float32).to(device)
train_labels = torch.tensor(df[train_label_columns].values, dtype=torch.float32).to(device)
for i in range(1000-1):
    train_labels[i][0] = (train_labels[i][0] * 100)
    train_labels[i][1] = (train_labels[i][1] * 100)
    train_labels[i][2] = (train_labels[i][2] * 100)
    train_labels[i][3] = (train_labels[i][3] * 1000)
    train_labels[i][4] = (train_labels[i][4] * 1000)
    train_labels[i][5] = (train_labels[i][5] * 1000)
#测试数据
dg = pd.read_csv('./4dataset1000.csv')
test_data_columns = dg.columns[:27]
test_label_columns = dg.columns[27:]  # 只选择第一个output的列
test_data = torch.tensor(dg[test_data_columns].values, dtype=torch.float32).to(device)
test_labels = torch.tensor(dg[test_label_columns].values, dtype=torch.float32).to(device)
for i in range(1000 - 1):
    test_labels[i][0] = (test_labels[i][0] * 100)
    test_labels[i][1] = (test_labels[i][1] * 100)
    test_labels[i][2] = (test_labels[i][2] * 100)
    test_labels[i][3] = (test_labels[i][3] * 1000)
    test_labels[i][4] = (test_labels[i][4] * 1000)
    test_labels[i][5] = (test_labels[i][5] * 1000)

# 将数据转换为 PyTorch 的 DataLoader
train_dataset = TensorDataset(train_data, train_labels)
train_loader = DataLoader(train_dataset, batch_size=1024, shuffle=True)

test_dataset = TensorDataset(test_data, test_labels)
test_loader = DataLoader(test_dataset, batch_size=1024, shuffle=True)


def training_step(batch,model):
    input_data, target = batch
    X, y = input_data.to(device), target.to(device)
    yp = model(X)
    loss = nn.MSELoss()(yp,y)
    return loss

def training_model(model, optimizers, training_step, lr_schedulers, max_steps, max_epochs):
    
    # learning_rate = 0.000008       #0.000008
    # weight_decay = 0.01
    epochs = 800
    criterion = nn.MSELoss()
    #optimizer = optim.Adam(model.parameters(), lr=learning_rate, weight_decay=weight_decay)

    # 存储训练损失
    train_losses = []
    test_losses = []
    validation_losses = []

    # 训练模型
    for epoch in range(epochs):
        print(f'Epoch {epoch} start!')
        for batch_data, batch_labels in train_loader:
            
            # 前向传播
            outputs = model(batch_data)
            # print('output_pre',outputs)
            # print('output_real',batch_labels)
            loss = criterion(outputs, batch_labels)
            optimizers.zero_grad()
            # 反向传播和优化 
            loss.backward()
            optimizers.step()
            print(f'training loss is {loss.item()} !')


def evaluating_model(model):
    #model.eval()
    with torch.no_grad():
        criterion = nn.MSELoss()
        test_loss_all =[]
        for x, y in test_loader:
            test_outputs = model(x)
            test_loss = criterion(test_outputs, y)
            test_loss_all.append(test_loss.item())
            print(f'Test Loss: {np.mean(test_loss_all):.4f}')
    return np.mean(test_loss_all)

def main():
    # traced_optimizer = nni.trace(SGD)(model_to_quantize.parameters(), lr=0.01,momentum=0.9, weight_decay=5e-4) 
    # #evaluator = TorchEvaluator(training_func=train_model, optimizers=traced_optimizer, training_step=training_step,evaluating_func=get_evaluation_func(robust_model,is_qat=QAT))  #, evaluating_func=self.get_evaluation_func(robust_model,is_qat=QAT) type: ignore
    # evaluator = TorchEvaluator(training_func=train_model, optimizers=traced_optimizer, training_step=training_step, evaluating_func=get_evaluation_func(model_to_quantize))  #, evaluating_func=self.get_evaluation_func(robust_model,is_qat=QAT) type: ignore

    # quantizer = PtqQuantizer(model_to_quantize, quantizer_config_list, evaluator)
    # calibration_config = quantizer.compress(max_steps=1, max_epochs=5)
    # torch.save(model_to_quantize.state_dict(),'model_gtq_4bit_state_dict.pth')

    #模型
    model = torch.load('./weights_and_biases_after_training_9_21(1).pth').to('cpu')
    bit_width = 'int8'
    quantizer_config_list = [{
            'op_types': ['BatchNorm1d', 'Linear'],
            'target_names': ['_input_', 'weight','bias','_output_'],
            'quant_dtype': bit_width,
            'quant_scheme': 'symmetric',
            'granularity': 'default'
            },{
            'op_types': ['ReLU'],
            'target_names': ['_output_'],
            'quant_dtype': bit_width,
            'quant_scheme': 'affine',
            'granularity': 'default'
            }]
    optimizer = nni.trace(Adam)(model.parameters(), lr=0.01, weight_decay=5e-4) #momentum=0.9 之前的输出一直是inf或nan，优化器从SGD换成Adam竟然就好了, 学习率由0.01调到0.000008
    evaluator = TorchEvaluator(training_model, optimizer, training_step)  # type: ignore
    quantizer = QATQuantizer(model, quantizer_config_list, evaluator, 10000)
    real_input = next(iter(train_loader))[0].to(device)
    quantizer.track_forward(real_input)

    start = time.time()
    _, calibration_config = quantizer.compress(None, max_epochs=5)
    print(f'pure training 5 epochs: {time.time() - start}s')

    print(calibration_config)
    start = time.time()
    acc = evaluating_model(model)
    print(f'quantization evaluating: {time.time() - start}s    Acc.: {acc}')
    # with open('scale.json', 'w') as f:
    #     json.dump(calibration_config, f)
    return calibration_config


def convert_float_to_int(calibration_config):
    model_path ='weights_and_biases_after_training_9_21(1).pth'
    model = torch.load(model_path).to('cpu')
    quantized_tensors = {}

    def process_tensor(tensor, scale, zero_point):
        # 减去 zero_point
        tensor_sub_zp = tensor + zero_point
        # 除以 scale
        tensor_div_scale = tensor_sub_zp / scale
        # 四舍五入并转换为整数
        #tensor_quantized = torch.round(tensor_div_scale).to(torch.int8)
        tensor_quantized = torch.round(tensor_div_scale).to(torch.int8)
        return tensor_quantized


    for name in model.state_dict():
        if 'weight' in name:
            print('current process: ',name)
            tensor = model.state_dict()[name]

            # 获取对应的量化参数
            layer_name = name.split('.')[0]  # 假设层名是 state_dict 键的第一部分
            if layer_name in calibration_config and 'weight' in calibration_config[layer_name]:
                config = calibration_config[layer_name]['weight']
                scale = config['scale']
                zero_point = config['zero_point']
                
                # 处理张量
                quantized_tensor = process_tensor(tensor, scale, zero_point)
                print('quantized tensor is ',quantized_tensor)
                quantized_tensors[name] = quantized_tensor
        elif 'bias' in name:
            print('current process: ',name)
            tensor = model.state_dict()[name]

            # 获取对应的量化参数
            layer_name = name.split('.')[0]  # 假设层名是 state_dict 键的第一部分
            if layer_name in calibration_config and 'bias' in calibration_config[layer_name]:
                config = calibration_config[layer_name]['bias']
                scale = config['scale']
                zero_point = config['zero_point']
                
                # 处理张量
                quantized_tensor = process_tensor(tensor, scale, zero_point)
                print('quantized tensor is ',quantized_tensor)
                quantized_tensors[name] = quantized_tensor
            
    torch.save(quantized_tensors, 'quantized_weights_int8.pth')
        
if __name__ == '__main__':
    calibration_config = main()
    convert_float_to_int(calibration_config)
    