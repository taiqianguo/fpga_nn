import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import pandas as pd
from torchvision.transforms import Normalize
import matplotlib.pyplot as plt

# 定义更复杂的神经网络模型和加入正则化
class ComplexMLP(nn.Module):
    def __init__(self, input_size, hidden_size1, hidden_size2, hidden_size3, hidden_size4, hidden_size5, hidden_size6, hidden_size7, hidden_size8, output_size):
        super(ComplexMLP, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size1)
        self.bn1 = nn.BatchNorm1d(hidden_size1)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Linear(hidden_size1, hidden_size2)
        self.bn2 = nn.BatchNorm1d(hidden_size2)
        self.relu2 = nn.ReLU()
        self.fc3 = nn.Linear(hidden_size2, hidden_size3)
        self.bn3 = nn.BatchNorm1d(hidden_size3)
        self.relu3 = nn.ReLU()
        self.fc4 = nn.Linear(hidden_size3, hidden_size4)
        self.bn4 = nn.BatchNorm1d(hidden_size4)
        self.relu4 = nn.ReLU()
        self.fc5 = nn.Linear(hidden_size4, hidden_size5)
        self.bn5 = nn.BatchNorm1d(hidden_size5)
        self.relu5 = nn.ReLU()
        self.fc6 = nn.Linear(hidden_size5, hidden_size6)
        self.bn6 = nn.BatchNorm1d(hidden_size6)
        self.relu6 = nn.ReLU()
        self.fc7 = nn.Linear(hidden_size6, hidden_size7)
        self.bn7 = nn.BatchNorm1d(hidden_size7)
        self.relu7 = nn.ReLU()
        self.fc8 = nn.Linear(hidden_size7, hidden_size8)
        self.bn8 = nn.BatchNorm1d(hidden_size8)
        self.relu8 = nn.ReLU()
        self.fc9 = nn.Linear(hidden_size8, output_size)

    def forward(self, x):
        x = self.fc1(x)
        x = self.bn1(x)
        x = self.relu1(x)
        x = self.fc2(x)
        x = self.bn2(x)
        x = self.relu2(x)
        x = self.fc3(x)
        x = self.bn3(x)
        x = self.relu3(x)
        x = self.fc4(x)
        x = self.bn4(x)
        x = self.relu4(x)
        x = self.fc5(x)
        x = self.bn5(x)
        x = self.relu5(x)
        x = self.fc6(x)
        x = self.bn6(x)
        x = self.relu6(x)
        x = self.fc7(x)
        x = self.bn7(x)
        x = self.relu7(x)
        x = self.fc8(x)
        x = self.bn8(x)
        x = self.relu8(x)
        x = self.fc9(x)
        return x

# 设置设备
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 超参数
input_size = 27
hidden_size1 = 512*2*4
hidden_size2 = 512*2*4
hidden_size3 = 512*2*4
hidden_size4 = 256*2*4
hidden_size5 = 128*2*4
hidden_size6 = 128*2*4
hidden_size7 = 128*2*4
hidden_size8 = 128*2*4
#idden_size9 = 128*4*3
output_size = 6  # 只有一个output
learning_rate = 0.000008       #0.000008
weight_decay = 0.01
epochs = 800

# 训练数据dac
df = pd.read_csv('4dataset50000.csv')
train_data_columns = df.columns[:27]
train_label_columns = df.columns[27:]  # 只选择第一个output的列
train_data = torch.tensor(df[train_data_columns].values, dtype=torch.float32).to(device)
train_labels = torch.tensor(df[train_label_columns].values, dtype=torch.float32).to(device)
for i in range(50000-1):
    train_labels[i][0] = (train_labels[i][0] * 100)
    train_labels[i][1] = (train_labels[i][1] * 100)
    train_labels[i][2] = (train_labels[i][2] * 100)
    train_labels[i][3] = (train_labels[i][3] * 1000)
    train_labels[i][4] = (train_labels[i][4] * 1000)
    train_labels[i][5] = (train_labels[i][5] * 1000)

# 测试数据
dg = pd.read_csv('4dataset1000.csv')
test_data_columns = dg.columns[:27]
test_label_columns = dg.columns[27:]  # 只选择第一个output的列
test_data = torch.tensor(dg[test_data_columns].values, dtype=torch.float32).to(device)
test_labels = torch.tensor(dg[test_label_columns].values, dtype=torch.float32).to(device)
for i in range(1000 - 1):
    test_labels[i][0] = (test_labels[i][0] * 100)
    test_labels[i][1] = (test_labels[i][1] * 100)
    test_labels[i][2] = (test_labels[i][2] * 100)
    test_labels[i][3] = (test_labels[i][3] * 1000)
    test_labels[i][4] = (test_labels[i][4] * 1000)
    test_labels[i][5] = (test_labels[i][5] * 1000)

#验证数据
dh = pd.read_csv('4dataset10000.csv')
validation_data_columns = dh.columns[:27]
validation_label_columns = dh.columns[27:]  # 只选择第一个output的列
validation_data = torch.tensor(dh[validation_data_columns].values, dtype=torch.float32).to(device)
validation_labels = torch.tensor(dh[validation_label_columns].values, dtype=torch.float32).to(device)
for i in range(10000 - 1):
    validation_labels[i][0] = (validation_labels[i][0] * 100)
    validation_labels[i][1] = (validation_labels[i][1] * 100)
    validation_labels[i][2] = (validation_labels[i][2] * 100)
    validation_labels[i][3] = (validation_labels[i][3] * 1000)
    validation_labels[i][4] = (validation_labels[i][4] * 1000)
    validation_labels[i][5] = (validation_labels[i][5] * 1000)

# 训练模型
model = ComplexMLP(input_size, hidden_size1, hidden_size2, hidden_size3, hidden_size4, hidden_size5, hidden_size6, hidden_size7, hidden_size8,output_size).to(device)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=learning_rate, weight_decay=weight_decay)

# 将数据转换为 PyTorch 的 DataLoader
train_dataset = TensorDataset(train_data, train_labels)
train_loader = DataLoader(train_dataset, batch_size=1024, shuffle=True)

# 存储训练损失
train_losses = []
test_losses = []
validation_losses = []

# 训练模型
for epoch in range(epochs):
    for batch_data, batch_labels in train_loader:
        # 前向传播
        outputs = model(batch_data)
        loss = criterion(outputs, batch_labels)

        # 反向传播和优化
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    if (epoch + 1) %1 == 0:
        with torch.no_grad():
            test_outputs = model(test_data)
            test_loss = criterion(test_outputs, test_labels)

        # 记录测试损失
        test_losses.append(test_loss.item())
        print(f'Epoch [{epoch + 1}/{epochs}], Train Loss: {loss.item():.4f}, Test Loss: {test_loss.item():.4f}')
        print('Test Predictions:')
        print(test_outputs[:10].detach().cpu())  # 打印前5个样本的模型输出
        print('True Labels:')
        print(test_labels[:10].detach().cpu())  # 打印前5个样本的真实标签

# 模型训练完成，使用测试集进行评估
with torch.no_grad():
    validation_outputs = model(validation_data)
    validation_loss = criterion(validation_outputs, validation_labels)

print(f'Test Loss: {validation_loss.item():.4f}')
# 打印测试集上的前几个预测结果
print('validation Predictions:')
print(validation_outputs[:10].detach().cpu())  # 打印前5个样本的模型输出
print('True Labels:')
print(validation_labels[:10].detach().cpu())  # 打印前5个样本的真实标签





# 在训练完成后保存权重和偏置
print("Training completed. Saving weights and biases...")

# 创建字典来存储权重和偏置
params_dict = {"Layer": [], "Weights": [], "Biases": []}

# 记录模型的每一层的权重和偏置
for name, param in model.named_parameters():
    if "weight" in name or "bias" in name:
        params_dict["Layer"].append(name)
        params_dict["Weights"].append(param.detach().cpu().numpy().tolist() if "weight" in name else "")
        params_dict["Biases"].append(param.detach().cpu().numpy().tolist() if "bias" in name else "")

# 将字典转换为数据框
df_params = pd.DataFrame(params_dict)

# 保存为 CSV 文件
df_params.to_csv("weights_and_biases_after_training.csv", index=False)

print("Weights and biases have been saved to weights_and_biases_after_training.csv")